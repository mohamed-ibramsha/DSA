package Advance2.Sorting;

public class MergeTwoSortedArray {

    public static void main(String[] args) {

        int[] A={7,10,11,14};
        int[] B={3,8,9};

        int[] C=new int[A.length+B.length];

        int p1=0;
        int p2=0;
        int K=0;
        while (p1 < A.length && p2 < B.length)
        {
            if(A[p1]<B[p2])
            {
                C[K]=A[p1];
                p1++;
            }
            else
            {
                C[K]=B[p2];
                p2++;
            }
            K++;

        }

        while (p1 < A.length)
        {
            C[K]=A[p1];
            p1++;
            K++;
        }

        while (p2 < B.length)
        {
            C[K]=B[p2];
            p2++;
            K++;
        }




    }
}
