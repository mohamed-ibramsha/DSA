package Advance2.Sorting;

public class SorttheArrayOrStableSort {

    public static void main(String[] args) {

        //int[] A={4,2,7,3,9,2};
        int[] A={-2,3,8,3,-2,3};

        int minElement=A[0];
        int maxElement=A[0];

        for(int i=1;i<A.length;i++)
        {
            minElement = Math.min(minElement,A[i]);
            maxElement=  Math.max(maxElement,A[i]);
        }

        int N=maxElement - minElement;

        int[] frqArray=new int[N+1];


        for(int i=0;i<A.length;i++)
        {
            int index=A[i]-minElement;
            frqArray[index]++;

        }

        int k=0;
        for(int i=0;i<frqArray.length;i++)
        {
            int cnt= frqArray[i];
            while(cnt > 0)
            {
                A[k]=i+minElement;
                cnt--;
                k++;
            }
        }






    }


}
