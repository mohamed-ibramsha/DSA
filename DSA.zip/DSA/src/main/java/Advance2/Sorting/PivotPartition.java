package Advance2.Sorting;

public class PivotPartition {

    public static void main(String[] args) {

        //Consider First Element is pivot,rearrange the elements for all i
        //if A[i]<pivot     --> left side
        // if A[i]> pivot --> right side


        //Note : All the elements are disctinct

        int[] A={54,26,93,17,77,31,44,55,20};

        int pivot=0;
        int left=pivot+1;
        int right=A.length -1;

        while(left<right)
        {
            if((A[pivot] < A[left]) &&  (A[pivot] > A[right]))
            {
                int temp=A[right];
                A[right]=A[left];
                A[left]=temp;
                left++;
                right--;
            }
            else if ((A[left] < A[right]) && A[left] < A[pivot])
            {
                left++;

            }
            else
            {
                right--;

            }
        }

        int temp=A[right];
        A[right]=A[pivot];
        A[pivot]=temp;

        for (int i=0;i<A.length;i++)
        {
            System.out.print(A[i]+",");
        }


    }
}
