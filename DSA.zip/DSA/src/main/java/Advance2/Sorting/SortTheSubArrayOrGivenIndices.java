package Advance2.Sorting;

public class SortTheSubArrayOrGivenIndices {


    public static void main(String[] args) {


        int[] A={4,8,-1,2,6,9,11,3,4,7,13,0};

        //Sort index from S=2 ,M=6, E=9
        //ans -> int[] A={4,8,-1,2,3,4,6,7,9,11,13,0};

        SortSubArray(A,2,6,9);
    }

    public static int[] SortSubArray(int[] A,int s, int m,int e)
    {

        int[] C=new int[e-s+1];

        int p1=s;
        int p2=m+1;
        int K=0;
        while (p1 <=m  && p2 <=e)
        {
            if(A[p1]<A[p2])
            {
                C[K]=A[p1];
                p1++;
            }
            else
            {
                C[K]=A[p2];
                p2++;
            }
            K++;

        }

        while (p1 <= m)
        {
            C[K]=A[p1];
            p1++;
            K++;
        }

        while (p2 <=e)
        {
            C[K]=A[p2];
            p2++;
            K++;
        }

        int x=0;
        for(int i=s;i<=e;i++)
        {
            A[i]=C[x];
            x++;
        }

        return A;
    }
}
