package Advance2.Sorting;

public class InversionCount {


    public static void main(String[] args) {

        //Find No,of paris where A[i] > A[j] ,condition i < j
//*********SOLVE THIS*********

        int[] A={10,3,8,15,6};


    }
}
