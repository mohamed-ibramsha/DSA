package Advance2.Sorting;

public class MergeSort {

    public static void main(String[] args) {

        //int[] A={10,15,3,8,6,2,17,12,18};
        int[] A={9,5,3,2,8};
        int[] ans=mergesort(A,0,A.length-1);

        for (int i=0;i<ans.length;i++)
        {
            System.out.print(ans[i]+",");
        }
    }

    public static int[] mergesort(int[] A,int s,int e )
    {
        if(s==e)
        {
            return A;
        }

        int m=(s+e)/2;

        mergesort(A,s,m);
        mergesort(A,m+1,e);
        SortTheSubArrayOrGivenIndices.SortSubArray(A,s,m,e);

        return A;
    }
}
