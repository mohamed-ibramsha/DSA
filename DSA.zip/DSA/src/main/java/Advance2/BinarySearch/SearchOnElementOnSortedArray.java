package Advance2.BinarySearch;

public class SearchOnElementOnSortedArray {

    public static void main(String[] args) {

        int[] A={3,6,9,12,14,19,20,23};
        int k = 23;

        int low=0;
        int high=A.length-1;

        while (low <=high)
        {
            int mid= low + (high-low)/2;

            if(A[mid]==k)
            {
                System.out.println(A[mid]+" True");
                break;
            }
            else if (A[mid] < k)
            {
                low=mid+1;
            }
            else
            {
                high=mid -1 ;
            }
        }



    }
}
