package Advance2.BinarySearch;

public class PainterPartition2 {

     /*
        Given N boards With length of Each Board

        A painter takes T unit of time to paint 1 unit of lenght
        A board can only br painted by 1 painter
        A painter can only pain board placed next to each other

        Find Minimum time required to paint all boards if p painter available
        other rules are same like prev problem
         */

    public static void main(String[] args) {

        int[] A={5,3,6,1,9};
        int t=2;int p=2;

        int high=0;int low=Integer.MIN_VALUE;
        for(int i=0;i<A.length;i++)
        {
            low=Math.max(A[i],low);
            high= high+A[i];

        }

        low= low*t;
        high= high*t;

        int minTime=0;
        while (low<=high)
        {

            int mid=low+(high-low)/2;
            int ActualPainter = paintercntPossible(A,t,mid);
            if(ActualPainter<=p)
            {
                minTime=mid;
                high=mid-1;
            }
            else if(ActualPainter > p)
            {
                low=mid+1;
            }



        }

        System.out.println(minTime);
    }

    public static int paintercntPossible(int[] A,int t,int x)
    {

        int painterCnt=1;
        int timeleft=x;
        for(int i=0;i<A.length;i++)
        {
            if(A[i]*t<=timeleft)
            {
                timeleft = timeleft - A[i]*t;
            }
            else
            {
                i--;
                painterCnt++;
                timeleft=x;
            }


        }
        return painterCnt;
    }
}
