package Advance2.BinarySearch;

public class UniqueElement {

    public static void main(String[] args) {

        int[] A={3,3,1,1,8,8,10,10,6,6,101,2,2,2,4,4};



        if(A[0]!=A[1])
        {
            System.out.println(A[0]);
        }
        if(A[A.length-1]!=A[A.length-2])
        {
            System.out.println(A.length-1);
        }

        int low=1;
        int high=A.length-2;
        while(low <=high)
        {
            int mid=low+(high-low)/2;

            if((A[mid]!=A[mid-1])&&(A[mid]!=A[mid+1]))
            {
                System.out.println(A[mid]);
                break;
            }

            if(A[mid]==A[mid-1])
            {
                mid=mid-1;
            }

             if(mid%2==1)
             {
                  high=mid-1;
             }
             else {
                 low =mid+2;
             }

        }
    }
}
