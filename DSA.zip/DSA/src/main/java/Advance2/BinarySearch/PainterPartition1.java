package Advance2.BinarySearch;

public class PainterPartition1 {

    public static void main(String[] args) {

        /*
        Given N boards With length of Each Board

        A painter takes T unit of time to paint 1 unit of lenght
        A board can only br painted by 1 painter
        A painter can only pain board placed next to each other

        Find minum numbre no of painter required to paint all boards in x unit of time
        return -1 if not possible
         */
        int[] A={5,3,6,1,9};
        System.out.println(paintercnt(5,A,2,30));
    }

    public static int paintercnt(int N,int[] A,int t,int x)
    {

        int painterCnt=1;
        int timeleft=x;
        for(int i=0;i<A.length;i++)
        {
            if(A[i]*t<=timeleft)
            {
               timeleft = timeleft - A[i]*t;
            }
            else
            {
                i--;
                painterCnt++;
                timeleft=x;
            }


        }
     return painterCnt;
    }
}
