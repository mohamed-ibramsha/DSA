package Advance2.BinarySearch;

public class AthMagicalNumber {
}
