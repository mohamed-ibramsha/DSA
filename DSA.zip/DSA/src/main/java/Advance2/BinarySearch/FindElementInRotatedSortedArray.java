package Advance2.BinarySearch;

public class FindElementInRotatedSortedArray {

    public static void main(String[] args) {
//****** CHECK THIS *********
        int[] A={10,11,12,13,17,20,23,25,26,1,3,5,6,8};
        int k=1;
        int low=0;int high=A.length-1;


        while(low<=high)
        {
            int mid=low+(high-low)/2;

            if(A[mid] == k)
            {
                System.out.println("True "+A[mid]);
                break;
            }

            if(A[mid] >= A[low])
            {
                if(A[mid] > k && A[low] <= k)
                {
                    high=mid-1;
                }
                else
                {
                    low=mid+1;

                }
            }
            else
            {
                if(A[mid] < k && k <= A[high])
                {
                    low = mid + 1;
                }
                else
                {
                    high=mid-1;
                }

            }
        }

    }
}
