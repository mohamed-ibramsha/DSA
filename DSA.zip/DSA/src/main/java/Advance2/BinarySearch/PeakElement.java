package Advance2.BinarySearch;

public class PeakElement {
    /*
    Given An Increasing and Decreasing array with Discintct elements, Find Peak Element

    A= {1,3,5,2} ans =5
    A= {1,3,5,6,2} ans=6
    A= {1,2,6}     ans=6
    A= {10,2,1}    ans=10
    A={5}          ans=5
     */
    public static void main(String[] args) {


        //int[] A = {1, 3, 5, 2};
        //int[] A= {1,3,5,6,2};
        //int[] A= {1,2,6};
        //int[] A= {10,2,1};
        //int[] A={5};
        int[] A={1,3,4,5,100,102,90,80,70,60,50,40,30,20,10,9,8};


        int N = A.length - 1;

        if (N == 0) {
            System.out.println(A[0]);
        }

        if((N==1)&&(A[N-1]>A[N]))
        {
            System.out.println(A[N-1]);
        }
        if((A[0]>A[1]))
        {
            System.out.println(A[0]);
        }


        int low=1;int high=N-1;

        while(low <= high)
        {
            int mid=low+(high-low)/2;


            if((A[mid] > A[mid-1])&&(A[mid] > A[mid+1]))
            {
                System.out.println("Peak Element "+ A[mid]);
                break;
            }
            else if ((A[mid] < A[mid-1])&&(A[mid] > A[mid+1]))
            {
                high=mid-1;
            }
            else
            {
              low=mid+1;
            }
        }



    }
}
