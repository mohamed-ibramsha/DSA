package Advance2.BinarySearch;

public class FindMaxofSqrtOfN {

    public static void main(String[] args) {

        int N=125;


        int low=0;int high=N;
        int ans=0;
        while (low <=high)
        {
            int mid=low+(high-low)/2;

            if(mid*mid <= N)
            {
                ans=mid;
                low=mid+1;

            }
            else {
                high=mid-1;
            }
        }

        System.out.println(ans);
    }
}
