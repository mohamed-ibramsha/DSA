package Advance2.BinarySearch;

public class SearchOnFirestIndexSortedArray {

    public static void main(String[] args) {

        int[] A={-5,-5,-3,0,0,1,1,5,5,5,5,5,5,5,5,8,10,10,15,16};

        int k = 0;

        int low=0;
        int high=A.length-1;
        int ans=-1;
        while (low <=high)
        {
            int mid= low + (high-low)/2;

            if(A[mid]==k)
            {
                ans=mid;
                high=mid-1;
            }
            else if (A[mid] < k)
            {
                low=mid+1;
            }
            else
            {
                high=mid -1 ;
            }
        }


        System.out.println(ans);
    }
}
