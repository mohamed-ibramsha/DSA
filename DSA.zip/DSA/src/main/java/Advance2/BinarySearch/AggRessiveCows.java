package Advance2.BinarySearch;

public class AggRessiveCows {


    /*
    Farmer John has built a new long barn with N stalls. Given an array of integers A of size N where each element of the array
    represents the location of the stall and an integer B which represents the number of cows.

His cows don't like this barn layout and become aggressive towards each other once put into a stall.
 To prevent the cows from hurting each other, John wants to assign the cows to the stalls,
 such that the minimum distance between any two of them is as large as possible. What is the largest minimum distance?

     */
    public static void main(String[] args) {


        int cows=3;
        int[] A={1,2,4,8,9};

        int c=1;int low=1;
        int maxDisctance=A[A.length-1]-A[0];
        int ans=Integer.MIN_VALUE;
        while (low <=maxDisctance)
        {
            if(isPossible(A,low,cows))
            {
                ans=Math.max(ans,low);
                //break;
        }
        low++;
        }

        System.out.println(ans);
    }


    public static  boolean isPossible(int[] A,int d,int x)
    {
        int cow=1;int lastPostition=A[0];
        for(int i=1;i<=A.length;i++)
        {
            if(cow==x)
            {
                return true;
            }

            if(A[i]-lastPostition >=d)
            {
                cow++;
                lastPostition=A[i];
            }


        }

    return false;
    }
}
