package Intermediate.BitManiPulation;

public class DecimalToBinary {

    /*
      A = 8
      8/2 = 4 - 0 remainder
      4/2 = 2 - 0 remainder
      2/2 = 1 - 0 remainer

      ans = 1000
     */
    public static void main(String[] args) {


        int A = 8;

        int X = A;
        int mul = 1;
        int ans = 0;
        while (X > 0) {

            int rem= X%2;
            ans = ans + (rem*mul);
            X = X/2;
            mul=mul*10;
        }

        System.out.println(ans);
    }
}
