package Intermediate.BitManiPulation;

public class BitsPlay {
    /*
                    A&B        A|B   A^B      ~ A / ~ B
            A  B
            0  1    0           1     1        Opposite
            0  0    0           0     0
            1  1    1           1     0
            1  0    0           1     1
     */

     //Check ith Bit Set Or Not -> Take AND Operator with 1 and that bit if result is 1 then bit is set or not
    // Toggle the ith Bit   -> Take ~ NoT operation with that Bit

    //Count Set Bits ->  -> Take AND Operator with 1 and that bit if result is 1 then Count++ and Right Shift the By 1 to elinate the counted bit

    //Check the number  is negative or not -> Take 1'complement (~) and + 1  if MSG is 1 then is -ve

    //Check ith is Bit if not Set the Bit ->  Take AND Operator with 1 and that bit if result is 1 then bit is set leave it
                                                //if not Take OR with 1 and that Bit  Result is that bit will be set

    // Left Shit  --->  A << N  = A * 2 ^ 2

    // Right Shift ---> A >> N = A / A ^N

    //Work on above formulas in papers




}
