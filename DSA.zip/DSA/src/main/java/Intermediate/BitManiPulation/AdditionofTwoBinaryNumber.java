package Intermediate.BitManiPulation;

public class AdditionofTwoBinaryNumber {

    public static void main(String[] args) {

        /*

                 1  0  1  = 5
                 0  1  1  = 3

               1  0  0  0  = 8
         */


        int A= 101 ;
        int B= 11;
        int ans=0;
        int mul=1;
        int num1=A,num2=B;
        int carry=0;
        while (num1 > 0 || num2 > 0 || carry > 0 )
        {
            int rem1=num1%10;
            int rem2=num2%10;

            int val= (rem1 + rem2)+carry;
            ans = ans + (( val%2) * mul);
            if(val/2 > 0)
            {
                carry = 1;
            }
            else
            {
                carry = 0;
            }
            num1=num1/10;
            num2=num2/10;
            mul=mul*10;


        }

        System.out.println(ans);
    }
}
