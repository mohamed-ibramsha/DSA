package Intermediate.BitManiPulation;

public class BinaryToDecimal {

    public static void main(String[] args) {

        /*
        A= [1 0 0 0]
        Ans = 2^3*1 + 2^2*0 + 2^1*0 + 2^0*0
            = 8
         */

        int A = 1000;

        int x=A;
        int mul=1;int ans=0;
        while (x > 0)
        {
            int rem=x%10;

            x = x / 10;
            ans = ans + (rem*mul);
            mul=mul*2;

        }

        System.out.println(ans);
    }
}
