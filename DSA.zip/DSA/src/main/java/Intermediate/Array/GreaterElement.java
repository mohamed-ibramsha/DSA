package Intermediate.Array;

public class GreaterElement {

    /*
    find the greater element in the array

    A[] = {1,7,5,3,7,2}
    1 is not greater than any element
    7 is greater than 5,3,2  = +1
    5 is greater than 3,2 = +1
    3 is greater than 2 = +1
    2 is  greater than  element 1= +1
    so,
    ans = 4



     */


    public static void main(String[] args) {
       // int a[] = {10, 10, 1}  ;
        int a[] = {1,7,5,3,7,2};

        int maxelement=a[0];
        int cnt=0;
        for(int i=1;i<a.length;i++)
        {
            if(a[i] > maxelement)
            {
                maxelement=a[i];
            }
        }


        for(int i=0;i<a.length;i++)
        {
            if(a[i]==maxelement)
            {
                cnt++;
            }
        }

        System.out.println(a.length -cnt);
    }
}
