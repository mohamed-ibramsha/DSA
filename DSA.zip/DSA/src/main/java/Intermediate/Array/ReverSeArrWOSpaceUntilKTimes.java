package Intermediate.Array;

public class ReverSeArrWOSpaceUntilKTimes {

    /*
    Rotate AnticlockWise Until K times
    A[] = {1,2,3,4,5,6}
    K = 9



     */
    public static void main(String[] args) {
        int A[] = {1,2,3,4,5,6};
        int K= 9;
            K = K % A.length;
          //  System.out.println(K+"  ");


        //Reverse untile 0, K-1
        ReverseArrayWithoutCreatingSpace.reverse(A,0,A.length-1);
        ReverseArrayWithoutCreatingSpace.reverse(A,0,K-1);
        ReverseArrayWithoutCreatingSpace.reverse(A,K,A.length-1);

    }

}

