package Intermediate.Array;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ReverseArrayWithoutCreatingSpace {

    /*
    A[] = {1,2,3,4,5}
    A= {5,4,3,2,1}
     */

  public static  void reverse(int [] A,int start,int end) {
      int p1 = start;
      int p2 = end;

      while (p1 < p2) {

          int temp = A[p2];
          A[p2] = A[p1];
          A[p1] = temp;
          p1++;
          p2--;
      }


      for (int i = 0; i < A.length; i++) {
          System.out.print(A[i] + ",");
      }
      System.out.println("/");

  }
}
