package Intermediate.ArraySlidingWindow;

public class PrintMAxSubarraySum {

    /*
    Print Max subArraySum in length of K
     */
    public static void main(String[] args) {


        int[] A = {-3, 4, -2, 5, 3, -2, 8, 2, -1, 4};

        int k = 5;

    /*
        S      e        Sum
        0       4       7
        1       5       8
        2       6       12
        3       7       16
        4       8       10
        5       9       11

        Ans =16

     */


        int ans=0;
        for (int i = 0; i < k; i++) {

            ans = ans + A[i];
        }

        int s=1,e=k;
        int sum=ans;
        while(e < A.length)
        {
            sum= sum - A[s-1] + A[e];
            ans=Math.max(ans,sum);
            s++;
            e++;
            System.out.print(sum+",");
        }

        System.out.print(ans);
    }


}
