package Intermediate.ArraySlidingWindow;

public class MinimumNoOfSwap {
    public static void main(String[] args) {

        /*
          A[] = { 25,30,2,18,7,6,9,50,3}
          B=10

          min Swap required 1 = move 3 to 18 th place

         */
       // int[] A = { 25,30,2,18,7,6,9,50,3};
        //int B=10;
        int[] A = { 1,12,10,3,14,10,5};

        int B=8;
        int GoodElements=0;
        for(int i=0;i<A.length;i++)
        {

            if(A[i] <= B)
            {
                GoodElements++;
            }
        }


        int BadElements= 0;
        int minSwapRequired=Integer.MAX_VALUE;
        for(int i=0;i<GoodElements;i++)
        {
            if(A[i] > B)
            {
                BadElements++;
            }


        }
        minSwapRequired = Math.min(BadElements,minSwapRequired);
       int s=1 , e= GoodElements;

        while(e < A.length)
        {
            if(A[e] > B)
            {
                BadElements++;
            }

            if(A[s-1] > B)
            {
                BadElements--;
            }

            minSwapRequired = Math.min(BadElements,minSwapRequired);
            s++;
            e++;
        }

        System.out.println(minSwapRequired);
    }
}
