package Intermediate.ArrayCarryfrwd;

import java.util.ArrayList;

public class LeadersArray {


    /*
    Problem Description

Given an integer array A containing N distinct integers, you have to find all the leaders in array A. An element is a leader if it is strictly greater than all the elements to its right side.

NOTE: The rightmost element is always a leader.
 A = [16, 17, 4, 3, 5, 2]

 Output = [17, 2, 5]
     */

    public static void main(String[] args) {

        int[] A={16, 17, 4, 3, 5, 2};

        ArrayList<Integer> ans=new ArrayList<>();

        int maxElement=A[A.length -1 ];
        ans.add(maxElement);
        for(int i=A.length -2;i>0 ;i--)
        {
            if(A[i] > maxElement)
            {
                maxElement=A[i];
                ans.add(A[i]);
            }
        }


        System.out.println(ans.toString());
    }
}
