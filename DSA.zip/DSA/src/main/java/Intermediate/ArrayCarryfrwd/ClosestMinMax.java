package Intermediate.ArrayCarryfrwd;

public class ClosestMinMax {
    /*
    Given an array A, find the size of the smallest subarray such that it contains at least one occurrence of the maximum value of the array

and at least one occurrence of the minimum value of the array

1.A = [2, 6, 1, 6, 9]

Subarray =[1,6,9]
ans = 3


2.A = [3,6,1,1,7,8,10,10,10,6]

Subarray = [1,1,7,8,2,2,2]
ans = 7
     */

    public static void main(String[] args) {

        int[] A={2, 6, 1, 6, 9};

        int max=A[0]; int min = A[0];
        for(int i=1;i<A.length;i++)
        {
            max= Math.max(max,A[i]);
            min= Math.min(min,A[i]);
        }

        System.out.println(max);
        System.out.println(min);
    }
}
