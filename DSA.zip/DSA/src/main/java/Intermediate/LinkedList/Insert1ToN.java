package Intermediate.LinkedList;

public class Insert1ToN {

    public static void main(String[] args) {


        int N = 5;
        Node2 head = new Node2(1);
        Node2 node = head;

        for (int i = 2; i <= N; i++) {

            Node2 temp=new Node2(i);
            node.next=temp;
            node=node.next;


        }
    }
}

class Node2{

    int data;
    Node2 next;

    Node2(int data)
    {
        this.data=data;
        this.next=null;
    }
}
