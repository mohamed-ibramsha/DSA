package Intermediate.Recursion;

public class SumofDigits {
    public static void main(String[] args) {

        /**
         * int A = 12345
         * ans = 1+2+3+4+5
         */

        System.out.println(sum(12345));
    }

    public static int sum(int x)
    {
        if(x==0) {
            return 0;
        }

        return sum(x/10)+x%10;
    }
}
