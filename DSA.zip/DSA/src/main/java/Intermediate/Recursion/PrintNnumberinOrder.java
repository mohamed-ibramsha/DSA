package Intermediate.Recursion;

public class PrintNnumberinOrder {

    public static void main(String[] args) {

        print(1,3);
    }

    public static void print(int a,int b)
    {
        if(a > b)
        {
            return;
        }


        System.out.println(a);
        print(a+1,b);
    }
}
