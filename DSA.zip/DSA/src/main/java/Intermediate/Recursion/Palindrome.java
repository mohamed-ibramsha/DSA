package Intermediate.Recursion;

public class Palindrome {
    public static void main(String[] args) {

        String s="NamaN";
        System.out.println(isPal(s.toCharArray(),0,s.length()-1));
    }

    public  static boolean isPal(char ch[],int s ,int e)
    {
        if(s > e)
        {
            return true;
        }

        if(ch[s]==ch[e] && isPal(ch,s+1,e-1)==true)
        {

                return true;

        }
        else {
            return false;
        }
    }
}
