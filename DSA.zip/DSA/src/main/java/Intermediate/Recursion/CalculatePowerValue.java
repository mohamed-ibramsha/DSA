package Intermediate.Recursion;

public class CalculatePowerValue {
    public static void main(String[] args) {


        System.out.println(Pvalue(5,5));
    }


    public static long Pvalue(long a,long n)
    {

        if(n==0)
        {
            return 1;
        }
        long x = Pvalue(a, n / 2);
        if(n%2==0) {

            return x * x;
        }
        else {

            return x * x * a;
        }
    }
}
