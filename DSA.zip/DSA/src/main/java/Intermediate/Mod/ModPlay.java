package Intermediate.Mod;

public class ModPlay {

    // (A+B)%p=  (A%p + B%p ) %p  -- same applies to mul also

    //(A%p)%p = A%p becaues value wont change even if you lot of times same value with mod

    //Divisible rules for 3

    //if any number is divisible or not --- like 3875274
    //we can take indidual number then do plus take whole mod of 3
    //becuse any number power vakue wih  10%3, 10^2%2.... always =1

    //Divible rule of 9 also same like 3

    //Divible rule for 4

    /*
      1%4=1
      10%4=2
      100%4=0
      1000%4 = 0

      so from 10 power 2 and 10 power 3 onwards mod value is 0

      so check last two digit is divisible by 4 or not
     */

    //Divible rule for 8

    /*
      1%8=1
      10%8=2
      100%8=4
      1000%8 = 0
      10000%8 = 0

      so from 10 power 3 and 10 power 4 onwards mod value is 0

      so check last three digit is divisible by 4 or not
     */
}
