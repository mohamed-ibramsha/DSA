package Intermediate.strings;

public class lowerCaseToUpperCase {
    public static void main(String[] args) {

        String s="mohamedibramsha";

        for (int i=0;i<s.length();i++) {
            char c=(char)(s.charAt(i) - 32) ;

            System.out.print(c);

        }


    }
}
