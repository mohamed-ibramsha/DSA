package Intermediate.strings;

public class LongestPolindrom {

    public static void main(String[] args) {
        String s="madam";


        int z=s.length()-1;
        int x=0;
        while (x < z )
        {
            if(s.charAt(x)==s.charAt(z))
            {
                z--;
                x++;
            }
            else
            {
                System.out.println("false");
                break;
            }
        }

     System.out.println("true");
    }
}
