package Intermediate.strings;

public class SortTheString {
    public static void main(String[] args) {

        String s="xsafzrtuxbnwqszpaa";

        System.out.println((int)('a'-97));
        int[] c=new int[26];


        for(int i=0;i<s.length();i++)
        {
            int index=s.charAt(i)-97; //'a'
            c[index] =c[index] +1;
        }

        for(int i=0;i<c.length;i++)
        {
            for(int j=0;j<c[i];j++)
            {
                char x = (char)(i+97);
                System.out.print(x);
            }
        }
    }
}
