package Intermediate.Trees;

public class TreeSizeAndHeight {

    public static void main(String[] args) {


        System.out.println("Tree Size " +size(addnodes()));
        System.out.println("Tree Height " +height(addnodes()));

    }
    public static int size(TNode A)
    {
        if(A ==null)
        {
            return 0;
        }
            int lst = size(A.left);
            int rst = size(A.right);
            return lst + rst + 1;

    }

    public static int height(TNode A)
    {
        if(A ==null)
        {
            return 0;
        }
        int lst = height(A.left);
        int rst = height(A.right);
        return Math.max(lst,rst) +1;

    }

    public static TNode addnodes()
    {
        TNode A=new TNode(1);
        TNode B= new TNode(7);
        TNode C= new TNode(8);
        TNode D= new TNode(9);
        TNode E= new TNode(10);
        TNode F= new TNode(4);
        TNode G= new TNode(2);
        TNode H= new TNode(6);
        TNode I= new TNode(11);
        TNode J= new TNode(19);
        TNode K= new TNode(8);
        TNode L= new TNode(21);


        A.left=B;
        A.right=C;
        B.left=D;
         B.right=E;
//        C.left=F;
//       C.right=G;
        E.left=H;
//        F.right=I;
//        G.left=K;
//        G.right=L;
//        I.left=J;

        return A;
    }
}

class TNode{

    int data;
    TNode left;
    TNode right;


    TNode(int data)
    {
        this.data=data;
        this.left=null;
        this.right=null;
    }

}

