package Intermediate.Trees;

public class TreeInPrePostSumTraversal {

    public static void main(String[] args) {


        System.out.println( sum(addnodes()));
        preOrder(addnodes());
        System.out.println();
        postOrder(addnodes());
        System.out.println();
        inOrder(addnodes());
    }
    public static int sum(TNode1 A)
    {
        if(A==null)
        {
            return 0;
        }
       int lst=sum(A.left);
        int rst =sum(A.right);

        return lst+rst+A.data;


    }
    public static void preOrder(TNode1 A)
    {
        if(A==null)
        {
            return;
        }
        System.out.print(A.data+",");
        preOrder(A.left);
        preOrder(A.right);


    }
    public static void postOrder(TNode1 A)
    {
        if(A==null)
        {
            return;
        }

        postOrder(A.left);
        postOrder(A.right);
        System.out.print(A.data+",");
    }
    public static void inOrder(TNode1 A)
    {
        if(A==null)
        {
            return;
        }

        inOrder(A.left);
        System.out.print(A.data+",");
        inOrder(A.right);
    }

    public static TNode1 addnodes()
    {
        TNode1 A=new TNode1(1);
        TNode1 B= new TNode1(7);
        TNode1 C= new TNode1(8);
        TNode1 D= new TNode1(9);
        TNode1 E= new TNode1(10);
        TNode1 F= new TNode1(4);
        TNode1 G= new TNode1(2);
        TNode1 H= new TNode1(6);
        TNode1 I= new TNode1(11);
        TNode1 J= new TNode1(19);
        TNode1 K= new TNode1(8);
        TNode1 L= new TNode1(21);


        A.left=B;
        A.right=C;
        B.left=D;
        B.right=E;
//        C.left=F;
//       C.right=G;
        E.left=H;
//        F.right=I;
//        G.left=K;
//        G.right=L;
//        I.left=J;

        return A;
    }
}

class TNode1{

    int data;
    TNode1 left;
    TNode1 right;

    TNode1(int data)
    {
        this.data=data;
        this.right=null;
        this.left=null;
    }
}
