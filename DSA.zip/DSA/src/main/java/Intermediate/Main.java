package Intermediate;

import Intermediate.basics.ElecBill;

public class Main {
    public static void main(String[] args) {

        ElecBill elecBill = new ElecBill();
        elecBill.math();
    }
}