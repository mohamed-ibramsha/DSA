package Intermediate.Hashing;

import java.util.HashSet;

public class CheckValueisThereOrNot {

    public static void main(String[] args) {

        /*
         Check given value is there is or not
        On Q Queries

         */


        int[] A={3,15,6,8,2,7,1};
        int[] Q={4,2,11,14,8};


        HashSet<Integer> hs=new HashSet<>();
        for (int i : A) {
            hs.add(i);
        }

        for(int j : Q)
        {
            if(hs.contains(j))
            {
                System.out.println(j+" - True ");
            }
            else
            {
                System.out.println(j+" - False ");
            }

        }
    }
}
