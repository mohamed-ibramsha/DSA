package Intermediate.Hashing;

import java.util.ArrayList;
import java.util.HashMap;

public class DistinctElementinWindow {

    public static void main(String[] args) {

       // int[] A={1,1,2,3,2};
        int[] A={6,3,7,3,8,9};
        int K=3;

        /*
        A = {1,1,2} = 2 discitnct
        A= { 1,2,3} = 3 distince
        A = {2,3,2} = 2 Distinct
         */


        //HashSet Approach will not work
        //becuase check this case 6,3,7,3,8,9  and k =3 with papers


        HashMap<Integer,Integer> hm=new HashMap<>();

        for(int i=0;i<K;i++)
        {
            hm.put(A[i],hm.getOrDefault(A[i],0)+1);
        }

        ArrayList<Integer> ans=new ArrayList<>();
        ans.add(hm.size());

        int s=1;int e=K;int N=A.length;

        while(e < N)
        {
            hm.put(A[e],hm.getOrDefault(A[e],0)+1);
            if(hm.containsKey(A[s-1]))
            {
                int val=hm.get(A[s-1]) - 1;

                if(val==0)
                {

                    hm.remove(A[s-1]);
                }
                else
                {
                    hm.put(A[s-1],val);
                }
            }

            ans.add(hm.size());
            s++;
            e++;
        }

        System.out.println(ans.toString());

    }

}
