package Intermediate.Hashing;

import java.util.HashMap;
import java.util.HashSet;

public class PairWithgivenSum {

    /*

        Check if there is any pair A[i] + A[j] ==k , but I==J should not be equal
     */

    public static void main(String[] args) {

        int[] A={8,9,1,-2,4,5,11,-6,7,5};
        int K=11;


        // X + Y = K
        //  Y = K - X

        //HashMap<Integer,Integer> hm=new HashMap<>();
        HashSet<Integer> hs=new HashSet<>();
        for(int i=0;i<A.length;i++)
        {
            int Y= K - A[i];
//            if(!hm.containsKey(Y)) {
//                hm.put(A[i], hm.getOrDefault(A[i],0)+1);
//            }
//            else
//            {
//                System.out.println("True - "+A[i]+"+"+Y);
//            }
            if(!hs.contains(Y)) {
                hs.add(A[i]);
            }
            else
            {
                System.out.println("True - "+A[i]+"+"+Y);
            }
        }
    }
}
