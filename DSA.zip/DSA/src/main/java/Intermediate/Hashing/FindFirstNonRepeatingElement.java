package Intermediate.Hashing;

import java.util.HashSet;

public class FindFirstNonRepeatingElement {

    public static void main(String[] args) {

        /*

          A = {1,2,3,1,2,5}
          ans = 3 is the first non repeating element
         */


        int[] A={1,2,3,1,2,5};
        HashSet<Integer> UniqueBucket=new HashSet<>();
        HashSet<Integer> DuplicateBucker=new HashSet<>();


        for(int i=0;i < A.length;i++)
        {
            if(UniqueBucket.contains(A[i]))
            {
                DuplicateBucker.add(A[i]);
            }
            else
            {
                UniqueBucket.add(A[i]);
            }
        }

        for(int i=0;i<A.length;i++)
        {
            if(!DuplicateBucker.contains(A[i]))
            {
                System.out.println(A[i]);
                break;
            }
        }
    }

}
