package Intermediate.Hashing;

import java.util.HashMap;

public class CheckAnYSubArraySumIsZero {

    /*
     A = {2 ,2,1,-3,4,3,1,-2,-3,2}
     index 1 to 3 Sum is Zero
     Index 3 to 8 sum is Zero

     A = { 2 ,-1 ,-1,4}
     Index 0 to 2 is Zero
     */
    public static void main(String[] args) {


        int[] A = {2, 2, 1, -3, 4, 3, 1, -2, -3, 2};

        int[] psum = new int[A.length];


        psum[0]=A[0];
        if(psum[0]==0)
        {
            System.out.println("true");
        }


        for(int i=1;i<A.length;i++)
        {
            psum[i]=psum[i-1]+A[i];
        }

        HashMap<Integer,Integer> hm=new HashMap<>();

        for(int i=0;i<psum.length;i++)
        {

            hm.put(psum[i],hm.getOrDefault(psum[i],0)+1);

            if(hm.get(psum[i]) > 1)
            {
                System.out.println("True");
            }
        }
    }


}
