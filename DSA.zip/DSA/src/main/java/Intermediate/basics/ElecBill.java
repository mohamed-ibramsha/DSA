package Intermediate.basics;

import java.util.Scanner;

public class ElecBill {


    //Scanner s=new Scanner(System.in);

    public static void math() {
        int a = 123456;
        int x=a;
        int r=0;
        while (x > 0)
        {
           r=r*10;
           r=r+x%10;
            x=x/10;
        }

    }




}
