package Intermediate.basics;

import java.lang.System;

public class IoDataTypeLoops {


    public static void main(String[] args) {

        System.out.println(10+20+"hi");

        System.out.println("Hi"+10+20);

        long a=10;
        int x=(int)a;

        System.out.println(x);

        long b=10000000000L;
        int y=(int)b;
        System.out.println(y);


        float c=10.30f;
        System.out.println(c);


        int num1=100000;
        int num2=100000;
        long num3 =num1*num2;
        System.out.println(num3);

        System.out.println(10%2);

        System.out.println(10%4);
/*
       Whenever a string appears, Java treats everything from that point as string concatenation.
       So:
        int + int + String → numbers are added first, then string added

       String + int + int → all are concatenated as strings
*/

        /**
         * Primitive
         *        Bool 1bit
         *        Numberic
         *
         *             Char  16bit
         *             Integer
         *                  Byte 8bit
         *                  short
         *                  int
         *                  long
         *
         *                  Float
         *                  Double
         *
         *  Non Primitive
         *              String
         *              Array
         *
         *
         */


    }
}
