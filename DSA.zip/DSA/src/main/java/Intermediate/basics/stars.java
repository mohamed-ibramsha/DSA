package Intermediate.basics;

public class stars {
    public static void main(String[] args) {

        /*
        *
        * *
        * * *

    r =1 , S=1
    r=2  , S=2
         */

//
//      for (int r=0;r<=5;r++)
//      {
//          for (int c=0;c<=r;c++)
//          {
//              System.out.print("*");
//          }
//          System.out.println();
//      }

        /*
            _ _ *
            _ * *
            * * *
            N=3
            R |  Space | Star
            1 |  2     | 1
            2  | 1     | 2
            3|  0      | 3

            space = N - R




         */

        for ( int r=1;r<=3 ;r++)
        {
            for (int c=1;c<=(3-r);c++)
            {
                System.out.print("_");
            }
            for (int s=1;s<=r;s++)
            {
                System.out.print("*");
            }
            System.out.println();
        }

    }
}
