package Intermediate.ArraySubArray;

public class SumOfAllSubarray {
    /*
    A={4,-1,3}
    4 =4
    4+(-1)=3
    4+(-1)+3=6
    -1 =-1
    -1+3=2
    3 = 3

    4+3+6+(-1)+2+3
    ans = 17
     */
    public static void main(String[] args) {



    int[] A = {4, -1, 3};
    int N = A.length;
    int sum=0;
    for(int i = 0; i<N;i++)
    {
        sum = sum+ (A[i]*(i+1)*(N-i));
    }
    System.out.print(sum+"");
}
}
