package Intermediate.ArraySubArray;

public class MaximumSubarray {
    /**

     */

    public static void main(String[] args) {
        int[] A={2,1,3,4,5};


        //Psum Approach

        int[] psum=new int[A.length];
        psum[0]=A[0];
        int maxSubarray=psum[0];
        for(int i=1;i< A.length;i++)
        {
             psum[i]=psum[i-1]+A[i];
            System.out.print(psum[i]+",");
             maxSubarray= Math.max(maxSubarray , psum[i]);

        }


        for(int i=1;i<A.length;i++)
        {
            for (int j=i;j<A.length;j++)
            {
                System.out.print(psum[j]-psum[i-1]+",");
                maxSubarray= Math.max(maxSubarray , psum[j]-psum[i-1]);
            }
            //System.out.println();
        }
        System.out.println("Max Subbarray is "+maxSubarray);



        //CarryFrwd Approach

        int maxCarryfrwd=-Integer.MAX_VALUE;
        for(int i=0;i<A.length;i++)
        {
            int sum=0;
            for (int j=i;j<A.length;j++)
            {
               sum =sum+A[j];
            }

            maxCarryfrwd=Math.max(sum,maxCarryfrwd);
        }
        System.out.println("Max Subbarray carryfrwd "+maxCarryfrwd);
    }
}
