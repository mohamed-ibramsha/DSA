package Intermediate.ArraySubArray;

public class PrintAllSubarray {

    /*
    Print All Subarray

    A= {1,2,3,4,5}


     */

    public static void main(String[] args) {

        int[] A={1,2,3,4,5};

        for(int i=0;i<A.length;i++)
        {
            for (int j=0 ; j< A.length;j++)
            {
                for(int k=i;k<=j;k++) {
                    System.out.print(A[k]+",");
                }
                System.out.println();
            }

        }
    }
}
