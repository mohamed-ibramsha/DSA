package Intermediate.ArrayPrefixSum;

public class EqiliBriumIndex {

    /*
    You are given an array A of integers of size N.

Your task is to find the equilibrium index of the given array

The equilibrium index of an array is an index such that the sum of elements at lower indexes is equal to the sum of elements at higher indexes.

If there are no elements that are at lower indexes or at higher indexes, then the corresponding sum of elements is considered as 0.

Note:

Array indexing starts from 0.
If there is no equilibrium index then return -1.
If there are more than one equilibrium indexes then return the minimum index.

A = [-7, 1, 5, 2, -4, 3, 0]

Index 3 is
3 is an equilibrium index, because:
A[0] + A[1] + A[2] = A[4] + A[5] + A[6]
     */

    public static void main(String[] args) {
       // int A[]  = {-7, 1, 5, 2, -4, 3, 0};
        int[] A ={1,2,3,7,1,2,3};


        int[] LSum = new int[A.length];
        int[] RSum = new int[A.length];

        LSum[0] = A[0];
        RSum[A.length -1 ] = A[A.length -1];

        for(int i=1;i<A.length;i++)
        {
            LSum[i] = LSum[i-1]+A[i];
        }



        for(int i=A.length -2 ;i >=0 ;i--)
        {

                RSum[i] = RSum[i + 1] + A[i];

        }

        for(int i=0;i<A.length;i++)
        {
            if(LSum[i]==RSum[i])
            {
                System.out.print(i);
            }
        }

    }
}
