package Intermediate.Sorting;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;

public class SortingTheArrayUsingComparator {

    public static void main(String[] args) {
       // int[] A={5,2,1,6,2,1,8};
        ArrayList<Integer> A=new ArrayList<>();
        A.add(5); A.add(2); A.add(6); A.add(2); A.add(1); A.add(8);
        Collections.sort(A, new Comparator<Integer>(){

            @Override
            public int compare(Integer x, Integer y) {

                if(x < y) {
                    return -1;
                }
                else if ( x > y)
                {
                    return 1;

                }
                else
                {
                    return 0;
                }
            }
        });


        System.out.println(A.toString());


        //Sort based on Factor

        ArrayList<Integer> B=new ArrayList<>();
        B.add(9);B.add(3);B.add(6);B.add(2);

        Collections.sort(B, new Comparator<Integer>(){

            @Override
            public int compare(Integer x, Integer y) {

                 int fx=factor(x); int fy=factor(y);
                if(fx < fy) {
                    return -1;
                }
                else if ( fx > fy)
                {
                    return 1;

                }
                else
                {

                    if(x < y) {
                        return -1;
                    }
                    else if ( x > y)
                    {
                        return 1;

                    }
                    else
                    {
                        return 0;
                    }
                }
            }
        });

        System.out.println(B.toString());

    }

    public static int factor(int X)
    {
        //Revise the concept for i is a factor and N/i also factor of I
        int cnt=0;
        for(int i=1;i<X;i++)
        {
            if(X%i==0)
            {
                cnt++;
            }
        }

        return cnt;
    }
}
