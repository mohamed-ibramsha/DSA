package Intermediate.Array2d;

public class PrintDiagonal {
    public static void main(String[] args) {

        int[][] A={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};

        //Left to Right

//        for(int row=0;row < A.length ;row++)
//        {
//            for (int col=0;col < A[0].length;col++)
//            {
//                if(row==col) {
//                    System.out.print(A[row][col] + ",");
//                }
//            }
//            System.out.println("");
//        }

//        int row=0;int col=0;
//
//        while(row < A.length && col < A[0].length)
//        {
//            System.out.print(A[row][col]+",");
//            row++;
//            col++;
//        }


        //Right to left


        int row = 0, col = A[0].length-1;
        while(row < A.length && col >= 0)
        {
            System.out.println(A[row][col]+",");
            row++;
            col--;

        }


    }
}
