package Intermediate.Array2d;

public class PrintSQuiral {

    public static void main(String[] args) {

        int[][] A={{1,2,3,4},{12,13,14,5},{11,16,15,6},{10,9,8,7}};
        int N=A.length;
        int row=0,col=0;

        while(N> 0) {

            for (int i = 0; i < N - 1; i++) {
                System.out.print(A[row][col] + ",");
                col++;
            }
            for (int i = 0; i < N - 1; i++) {
                System.out.print(A[row][col] + ",");
                row++;
            }
            for (int i = N - 1; i > 0; i--) {
                System.out.print(A[row][col] + ",");
                col--;
            }
            for (int i = N - 1; i > 0; i--) {
                System.out.print(A[row][col] + ",");
                row--;
            }
            col++;row++;
            N=N-2;
        }

        //Check notes for two type of problems @sliding window notes
        
    }
}
