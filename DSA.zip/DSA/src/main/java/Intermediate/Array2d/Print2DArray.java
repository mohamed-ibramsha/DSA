package Intermediate.Array2d;

public class Print2DArray {
    public static void main(String[] args) {

        int[][] A={{1,2,3,4},{5,6,7,8},{9,10,11,12}};


        for(int row=0;row < A.length ;row++)
        {
            for (int col=0;col < A[0].length;col++)
            {

                System.out.print(A[row][col]+",");
            }
            System.out.println("");
        }


    }
}
