package Intermediate.Array2d;

public class PrintAllDiagonalRightToLeft {
    public static void main(String[] args) {


      int[][] A={{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}};
        //int[][] A={{1,2,3},{5,6,7},{9,10,11},{13,14,15}};

        //First Print 0th col of all rows -first panel


        for(int col=0;col<A[0].length;col++)
        {
            int i=0,j = col;
            while (i < A.length && j >= 0)
            {

                System.out.print(A[i][j]+",");
                i++;
                j--;
            }
            System.out.println();

        }

        //Second panel
        //why row=1?
        for (int row=1;row < A.length;row++ )
        {
            int i=row,j=A[0].length-1;
            while(i < A.length&& j >=0)
            {
                System.out.print(A[i][j]+",");
                i++;
                j--;
            }
            System.out.println();
        }



    }
}
