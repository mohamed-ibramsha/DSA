package Advance1.InverQuesAdditional;

import java.util.ArrayList;
import java.util.List;

public class MergeIntervals {
    /*
    You have a set of non-overlapping intervals. You are given a new interval [start, end],
    insert this new interval into the set of intervals (merge if necessary).

You may assume that the intervals were initially sorted according to their start times.

Given intervals [1, 3], [6, 9] insert and merge [2, 5] .

Output 1:

 [ [1, 5], [6, 9] ]
     */

    public static void main(String[] args) {


        ArrayList<Interval> Ilist=new ArrayList<>();
        Interval I1=new Interval(1,5);
        Interval I2=new Interval(6,9);

        Ilist.add(I1);Ilist.add(I2);

        Interval mergeInterval=new Interval(2,5);

        ArrayList<Interval> ans =new ArrayList<>();


        for(int i=0;i<Ilist.size();i++)
        {
            int Currentstart = Ilist.get(i).start;
            int Currentend = Ilist.get(i).end;

            if(Currentend > mergeInterval.start)
            {
                int newMin=Math.min(Currentstart, mergeInterval.start);
                int newMax=Math.max(Currentend, mergeInterval.end);
                Interval newInterval = new Interval(newMin,newMax);
                ans.add(newInterval);
                for(int j=i+1;j<Ilist.size();j++)
                {


                }

            }

        }

    }

}
  class Interval {
     int start;
     int end;
     Interval() { start = 0; end = 0; }
     Interval(int s, int e) { start = s; end = e; }
 }
