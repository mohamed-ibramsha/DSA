package Advance1.Array1d;

public class MaxSumContiguousSubarray {

    /**
     *Given an array A of length N, your task is to find the maximum possible sum of any non-empty contiguous subarray.
     *
     * In other words, among all possible subarrays of A, determine the one that yields the highest sum and return that sum.
     * A = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
     * Output 2:
     *
     *  6
     *
     *  subarray [4,-1,2,1] has the maximum possible sum of 6.
     *
     *
     *
     */

    public static void main(String[] args) {

        // This approach is called Kadans Algorithem
        int[] A={-2, 1, -3, 4, -1, 2, 1, -5, 4};

        int sum=0;int ans=0;

        for(int i=0;i<A.length;i++)
        {
            sum = sum+A[i];
            if(sum < 0)
            {
                sum=0;
            }
            ans=Math.max(ans,sum);


        }

        System.out.println(ans);

    }
}
