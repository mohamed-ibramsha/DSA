package Advance1.Array1d;

public class RainWaterTrapped {
    /*
    Problem Description

Imagine a histogram where the bars' heights are given by the array A. Each bar is of uniform width, which is 1 unit. When it rains, water will accumulate in the valleys between the bars.

Your task is to calculate the total amount of water that can be trapped in these valleys.

Example:

The Array A = [5, 4, 1, 4, 3, 2, 7] is visualized with pen and paper . The total amount of rain water trapped in A is 11.



     */

    public static void main(String[] args) {

        int[] A={5, 4, 1, 4, 3, 2, 7};
        int N=A.length;

        //Create Lmax

        int[] Lmax=new int[N];
        Lmax[0]=A[0];
       for(int i=1;i<N;i++)
       {
           Lmax[i]=Math.max(Lmax[i-1],A[i]);
       }

        //Create Rmax

        int[] Rmax=new int[N];
        Rmax[N-1]=A[N-1];
        for(int i=N-2;i>=0;i--)
        {
            Rmax[i]=Math.max(Rmax[i+1],A[i]);
        }


        int ans=0;

        for(int i=0;i<N;i++)
        {
            ans = ans +Math.min(Lmax[i],Rmax[i])-A[i];
        }

        System.out.println(ans);

    }
}
