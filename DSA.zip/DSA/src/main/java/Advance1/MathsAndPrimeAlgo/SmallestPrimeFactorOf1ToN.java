package Advance1.MathsAndPrimeAlgo;

import java.util.Arrays;

public class SmallestPrimeFactorOf1ToN {
    public static void main(String[] args) {

        int N=50;

        int[] smallesPrime=new int[N+1];
        for(int i=2;i<=N;i++)
        {
            smallesPrime[i]=i;
        }



        for(int i=2;i<=N/2;i++)
        {
            if(smallesPrime[i]==i)
            {
                for(int j=i*i;j<=N;j=j+i)
                {
                    smallesPrime[j]=i;

                }
            }
        }

        for(int i=2;i<=N;i++)
        {

                System.out.print(smallesPrime[i]+",");

        }
    }
}
