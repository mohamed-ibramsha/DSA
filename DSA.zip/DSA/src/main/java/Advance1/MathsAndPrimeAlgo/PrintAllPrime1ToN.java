package Advance1.MathsAndPrimeAlgo;

import java.util.ArrayList;
import java.util.Arrays;

public class PrintAllPrime1ToN {
        /*
        using Sieve of Eratosthenes Algo
         */

    public static void main(String[] args) {

       int N=50;

       boolean[] primeArray=new boolean[N+1];
        Arrays.fill(primeArray,true);

        primeArray[0]=false;
        primeArray[1]=false;

        for(int i=2;i<=N/2;i++)
        {
            if(primeArray[i]==true)
            {
                for(int j=i*i;j<=N;j=j+i)
                {
                    primeArray[j]=false;

                }
            }
        }

        for(int i=1;i<=N;i++)
        {
            if(primeArray[i])
            {
                System.out.print(i+",");
            }
        }
    }
}
