package Advance1.MathsAndPrimeAlgo;

public class ModSumEqualtoM {

    /**
     *
     * Find (A[i]+A[j])%M =0 and i!=j
     *
     *
     * Do this later
     */
}
