package Advance1.Array2d;

public class AllSubArraySum {

    /*

        A = [4 9 6
            5 -1 2]

            ans = 166
     */

    //Work on TL and BR contribution in pen and paper
    public static void main(String[] args) {

        int[][] A={{4,9,6},{5,-1,2}};

        int sum=0;int N=A.length;int M=A[0].length;
        for(int i=0;i<N;i++)
        {
            for (int j=0;j<M;j++)
            {
                int TL=(i+1)*(j+1);
                int BR=(N-i)*(M-j);
                sum = sum + (TL*BR*A[i][j]);
            }
        }

        System.out.println(sum);

    }
}
