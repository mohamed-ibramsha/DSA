package Advance1.Array2d;

public class RowWithaximumNoOnes {
    /*

    Input1:
     A = [   [0, 1, 1]
         [0, 0, 1]
         [0, 1, 1]   ]


        Ans : Row 0 and 2 has maximum ones but min row is 0
Input 2:

 A = [   [0, 0, 0, 0]
         [0, 0, 0, 1]
         [0, 0, 1, 1]
         [0, 1, 1, 1]    ]

          Ans : Row 3  only has maximum ones
     */

    public static void main(String[] args) {

        int[][] A= {{0, 1, 1},
                    {0, 0, 1},
                    {1, 1, 1}};

        int row=0;int col=A.length -1 ;
        int ans=0;
        while(row < A.length && col >=0)
        {

          while(col >=0 && A[row][col]==1)
          {
              ans=row;
              col--;
          }
        row++;
        }

        System.out.println(ans);

    }
}
