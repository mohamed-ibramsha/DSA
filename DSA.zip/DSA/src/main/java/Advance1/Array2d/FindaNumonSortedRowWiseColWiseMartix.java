package Advance1.Array2d;

public class FindaNumonSortedRowWiseColWiseMartix {

    /**
     *
     */

    public static void main(String[] args) {

        int[][] A={{-5,-2,1,13},{-4,0,3,14},{-3,2,6,18}};

        int K=2;

        int row = 0 ,col =A[0].length -1 ;

        while(row < A.length && col >0 )
        {
            int Current=A[row][col];
            if(Current==K)
            {
                System.out.println("True");
                break;
            }
            else if (Current > K)
            {
                col--;
            }
            else
            {
                row++;
            }
        }
    }
}
