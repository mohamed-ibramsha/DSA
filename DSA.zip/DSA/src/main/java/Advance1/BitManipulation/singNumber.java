package Advance1.BitManipulation;

public class singNumber {
    /*

Given an array of integers, every element appears thrice except for one, which occurs once.

Find that element that does not appear thrice.

NOTE: Your algorithm should have a linear runtime complexity.

Could you implement it without using extra memory?
     */
    public static void main(String[] args) {

        int[] A={ 1, 2, 4, 3, 3, 2, 2, 3, 1, 1};

        int ans=0;
        for(int i=0;i<32;i++)
        {
            int cnt=0;
            for(int j=0;j<A.length;j++)
            {
                if(checkIthBit(A[j],i))
                {
                    cnt++;
                }
            }
            if(cnt%3==1)
            {
                ans = ans | (1<<i);
            }
        }

        System.out.println(ans);
    }

    public static boolean checkIthBit(int A,int i)
    {
        if((A&(1<<i)) > 0)
        {
            return true;
        }
        return false;
    }
}
