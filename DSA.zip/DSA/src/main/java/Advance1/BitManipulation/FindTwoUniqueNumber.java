package Advance1.BitManipulation;

public class FindTwoUniqueNumber {
    /*
Given an array of positive integers A, two integers appear only once, and all the other integers appear twice.
Find the two integers that appear only once.

Note: Return the two numbers in ascending order.
1.A = [5,4,7,6,7,4,5,2]
Output 1:
[6, 2]

2.A = [1, 2, 3, 1, 2, 4]

Output 2:
[3, 4]
     */
    public static void main(String[] args) {

        //int[] A={5,4,7,6,7,4,5,2};
        int[] A={1, 2, 3, 1, 2, 4};

        int x=0;
        for(int i=0;i<A.length;i++)
        {
            x = x ^ A[i];
        }

        int postition=0;
        for(int i=0;i<32;i++)
        {
            if((x | (1<<i)) ==x)
            {
                postition=i;
                break;
            }
        }

        int x1=0;int x2=0;

        for(int i=0;i<A.length;i++)
        {
            if((A[i]&(1<<postition)) > 0)
            {
                x1=x1^A[i];
            }
            else
            {
                x2=x2^A[i];
            }
        }
        System.out.println(x1+","+x2);
    }
}
