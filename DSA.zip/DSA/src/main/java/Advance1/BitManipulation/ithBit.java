package Advance1.BitManipulation;

public class ithBit {

    public static void main(String[] args) {

        countSetBits(5);
        CheckIthBit(5,0);
        UnsetIthBit(4,1);
    }

    public static void CheckIthBit(int A,int B)
    {
        /*
        You are given two integers A and B.
Return 1 if B-th bit in A is set
Return 0 if B-th bit in A is unset
         */
        if((A&(1<<B)) > 0)
        {
            System.out.println(1+" B th bit is set");
        }
        else
        {
            System.out.println(0+" B th bit is unset");
        }


    }

    public static void UnsetIthBit(int A ,int B)
    {
        /*
        If B-th bit in A is set, make it unset.
        If B-th bit in A is unset, leave as it is.
         */

        if((A&(1<<B)) > 0)
        {
            System.out.println(A^1<<B);
        }
        else
        {
            System.out.println(A);
        }

    }
    public static void countSetBits(int A)

    {
        int cont=0;
        while (A > 0) {
            if ((A & 1) > 0) {
                cont++;

            }

            A = A >> 1;

        }
        System.out.println("No of set Bits "+cont);
    }

}
