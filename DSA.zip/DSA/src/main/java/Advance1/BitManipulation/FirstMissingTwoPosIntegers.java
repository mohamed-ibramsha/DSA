package Advance1.BitManipulation;

public class FirstMissingTwoPosIntegers {
    /*
    A = [5, 1, 3, 6]
    output : [2, 4]

    A = [3, 2, 4]
    output :1,5
     */

    public static void main(String[] args) {

        int[] A={5,1,3,6};
        //int[] A={3,2,4};

        int N=A.length;
        int x1=0;int x2=0;
        for(int i=0;i<A.length;i++)
        {
            if(Math.abs(A[i])<=N)
            {
                int MarkPresence=A[i]-1;
                A[MarkPresence] = A[MarkPresence]*-1;
            }
        }

        for(int i=0;i<A.length;i++)
        {
            if(A[i] > 0 && (x1 == 0))
            {
                x1=i+1;
            }
            else if(A[i] > 0 && x1 > 0 && x2 ==0 )
            {
                x2=i+1;
            }

            if(x1>0 && x2 >0)
            {
                break;
            }
        }


        if(x1==0)
        {
            x1 = N+1;
        }

        if(x2==0&& x1>0)
        {
            x2=N+2;
        }

        System.out.println(x1+","+x2);
    }
}
