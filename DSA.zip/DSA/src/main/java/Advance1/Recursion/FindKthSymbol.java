package Advance1.Recursion;

public class FindKthSymbol {
/*
On the first row, we write a 0. Now in every subsequent row, we look at the previous row and replace each occurrence of 0 with 01, and each occurrence of 1 with 10.

Given row number A and index K, return the Kth indexed symbol in row A. (The values of K are 0-indexed.).

Input 1:

 A = 4
 K = 4

Explanation 2:

 Row 1: 0
 Row 2: 01
 Row 3: 0110
 Row 4: 01101001

 ans 1
 */

    //Draw Recursive Tree
    public static void main(String[] args) {

        System.out.println(Kval(4,6));
    }

    public static int Kval(int A,int K)
    {
        if(K==0)
        {
            return 0;
        }
        else if (K==1)
        {
            return 1;
        }

        if(K%2==0)
        {
            return Kval(A-1,K/2);
        }
       else
        {
            return 1- Kval(A-1,K/2);
        }
    }
}
