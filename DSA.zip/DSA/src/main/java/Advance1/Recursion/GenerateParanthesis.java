package Advance1.Recursion;

public class GenerateParanthesis {

    public static void main(String[] args) {

        genP( 2,"",0,0);

    }

    public static void genP(int N,String S,int open,int close)
    {
        if(S.length()==2*N)
        {
            System.out.println(S);
            return;
        }

        if(open < N)
        {
            genP(N,S+"(",open+1,close);
        }
        if(close < open)
        {
            genP(N,S+")",open,close+1);
        }

    }
}

