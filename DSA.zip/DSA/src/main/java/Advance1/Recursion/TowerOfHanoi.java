package Advance1.Recursion;

public class TowerOfHanoi {

    public static void main(String[] args) {

        TOH(3,'A','B','C');

    }

    public static void TOH(int N,char S,char H,char D)
    {
        if(N==0)
        {
            return;
        }
        TOH(N-1,S,D,H);
        System.out.println(N+" : "+ S +" to " + D );
        TOH(N-1,H,S,D);
    }
}
